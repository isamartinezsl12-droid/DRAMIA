# DRAMIA V1
Proyecto inicial de la app de streaming de dramas creados con IA.

## Incluye
- Inicio
- Catálogo por categorías
- Búsqueda
- Mi lista
- Perfil
- Ficha de drama
- Lista de capítulos
- Pantalla de reproducción simulada

## Para abrir
1. Instala Android Studio.
2. Abre esta carpeta como proyecto.
3. Deja que Gradle sincronice.
4. Ejecuta en un teléfono Android o emulador.

La siguiente etapa será conectar contenido real, cuentas y backend.
