package com.dastan.dramia

import android.app.*
import android.os.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import java.util.*

data class Drama(val title:String,val genre:String,val synopsis:String,val episodes:Int)

class MainActivity: Activity() {
    private val dramas = listOf(
        Drama("La Última Mentira","Drama · Suspenso","Descubrió el secreto. Ahora todos quieren silenciarla.",16),
        Drama("Herencia de Sangre","Drama · Misterio","Una herencia convierte a una familia en enemigos.",24),
        Drama("Habitación 309","Terror · Suspenso","Cada noche alguien desaparece detrás de esa puerta.",12),
        Drama("Contrato de Venganza","Romance · Drama","Se casó para vengarse. El problema fue enamorarse.",30),
        Drama("La Otra Vida","Drama · Oscuro","Volver del pasado tiene un precio.",18),
        Drama("Mentiras de Cristal","Drama · Suspenso","Todo parece perfecto hasta que alguien rompe el silencio.",20)
    )
    private val saved = mutableSetOf<String>()
    private val lime = Color.rgb(216,255,79)
    private val bg = Color.rgb(9,10,16)
    private val card = Color.rgb(23,25,35)

    override fun onCreate(b:Bundle?){ super.onCreate(b); showHome() }

    private fun base(): LinearLayout {
        return LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(20,24,20,12)
            setBackgroundColor(bg)
        }
    }
    private fun text(s:String,size:Float=16f,bold:Boolean=false)=TextView(this).apply{
        text=s;textSize=size;setTextColor(Color.WHITE)
        if(bold) typeface=android.graphics.Typeface.DEFAULT_BOLD
        setPadding(0,8,0,8)
    }
    private fun button(s:String, action:()->Unit)=Button(this).apply{
        text=s; setTextColor(Color.BLACK); setOnClickListener{action()}
        background=GradientDrawable().apply{setColor(lime);cornerRadius=24f}
    }
    private fun scroll(content:View){
        val sv=ScrollView(this); sv.setBackgroundColor(bg); sv.addView(content)
        setContentView(sv)
    }
    private fun header(root:LinearLayout, section:String){
        val row=LinearLayout(this); row.gravity=Gravity.CENTER_VERTICAL
        val logo=text("D R A M I A",25f,true); logo.setTextColor(lime)
        row.addView(logo,LinearLayout.LayoutParams(0,-2,1f))
        row.addView(text(section,14f))
        root.addView(row)
    }
    private fun nav(root:LinearLayout){
        val row=LinearLayout(this); row.gravity=Gravity.CENTER
        listOf("⌂ Inicio" to {showHome()}, "⌕ Buscar" to {showSearch()}, "♥ Mi lista" to {showSaved()}, "◉ Perfil" to {showProfile()})
            .forEach { (name,fn) -> row.addView(button(name,fn),LinearLayout.LayoutParams(0,55,1f).apply{setMargins(3,8,3,0)}) }
        root.addView(row)
    }

    private fun showHome(){
        val root=base(); header(root,"V1")
        root.addView(text("Historias que no existen... todavía.",14f))
        val hero=TextView(this).apply{
            text="LA ÚLTIMA MENTIRA\n\nElla descubrió el secreto.\nAhora todos quieren que muera."
            textSize=25f; setTextColor(Color.WHITE); setPadding(26,36,26,36)
            background=GradientDrawable().apply{colors=intArrayOf(Color.rgb(55,30,70),card);gradientType=GradientDrawable.LINEAR_GRADIENT;cornerRadius=34f}
        }
        root.addView(hero)
        root.addView(button("▶ VER AHORA"){showDetail(dramas.first())})
        root.addView(text("🔥 Tendencias",22f,true))
        dramas.take(4).forEach{root.addView(dramaCard(it))}
        root.addView(text("🤖 HECHO CON IA",22f,true))
        dramas.drop(4).forEach{root.addView(dramaCard(it))}
        nav(root);scroll(root)
    }
    private fun dramaCard(d:Drama):View{
        return LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(18,14,18,14)
            background=GradientDrawable().apply{setColor(card);cornerRadius=25f}
            setOnClickListener{showDetail(d)}
            addView(text(d.title,19f,true));addView(text(d.genre,13f));addView(text(d.synopsis,14f))
            layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,7,0,7)}
        }
    }
    private fun showSearch(){
        val root=base();header(root,"BUSCAR")
        val input=EditText(this).apply{hint="Busca un drama o escribe: traición, terror...";setTextColor(Color.WHITE);setHintTextColor(Color.GRAY)}
        root.addView(input)
        val results=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(button("BUSCAR"){
            results.removeAllViews()
            val q=input.text.toString().lowercase()
            dramas.filter{it.title.lowercase().contains(q)||it.genre.lowercase().contains(q)||it.synopsis.lowercase().contains(q)}
                .forEach{results.addView(dramaCard(it))}
            if(results.childCount==0) results.addView(text("No encontramos nada... todavía 👀"))
        })
        root.addView(results);nav(root);scroll(root)
    }
    private fun showSaved(){
        val root=base();header(root,"MI LISTA")
        val list=dramas.filter{saved.contains(it.title)}
        if(list.isEmpty()) root.addView(text("Tu lista está vacía.\nGuarda un drama con el botón ♥ MI LISTA."))
        else list.forEach{root.addView(dramaCard(it))}
        nav(root);scroll(root)
    }
    private fun showProfile(){
        val root=base();header(root,"PERFIL")
        root.addView(text("👤 Bella",28f,true))
        root.addView(text("Espectadora fundadora de DRAMIA 👀"))
        root.addView(text("Próximamente",21f,true))
        listOf("Historial de reproducción","Preferencias","Notificaciones","DRAMIA+").forEach{root.addView(text("• $it"))}
        nav(root);scroll(root)
    }
    private fun showDetail(d:Drama){
        val root=base();header(root,"DETALLE")
        root.addView(text(d.title,30f,true));root.addView(text(d.genre+" · "+d.episodes+" capítulos"))
        root.addView(text(d.synopsis,17f))
        root.addView(button("▶ VER CAPÍTULO 1"){showPlayer(d,1)})
        root.addView(button(if(saved.contains(d.title))"♥ QUITAR DE MI LISTA" else "♡ MI LISTA"){
            if(saved.contains(d.title)) saved.remove(d.title) else saved.add(d.title);showDetail(d)
        })
        root.addView(text("CAPÍTULOS",21f,true))
        (1..d.episodes).forEach{n->
            val b=button("E$n  ·  ${if(n==1)"El comienzo" else "Capítulo $n"}"){showPlayer(d,n)}
            root.addView(b,LinearLayout.LayoutParams(-1,55).apply{setMargins(0,4,0,4)})
        }
        root.addView(button("← VOLVER"){showHome()});scroll(root)
    }
    private fun showPlayer(d:Drama,n:Int){
        val root=base();header(root,"REPRODUCIENDO")
        val screen=TextView(this).apply{
            text="▶\n\n${d.title}\nCapítulo $n";gravity=Gravity.CENTER;textSize=24f;setTextColor(Color.WHITE)
            setPadding(20,100,20,100);background=GradientDrawable().apply{setColor(Color.BLACK);cornerRadius=28f}
        }
        root.addView(screen);root.addView(text("00:00  ━━━━━━━━━━━━━  06:00"))
        root.addView(button(if(n<d.episodes)"⏭ SIGUIENTE CAPÍTULO" else "✓ TEMPORADA TERMINADA"){
            if(n<d.episodes) showPlayer(d,n+1) else showDetail(d)
        })
        root.addView(button("← VOLVER A LA SERIE"){showDetail(d)});scroll(root)
    }
}
