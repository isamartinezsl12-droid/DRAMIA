plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.dastan.dramia"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.dastan.dramia"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
